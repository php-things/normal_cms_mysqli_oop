<?php
	$objAdmin = new General_Class();
?>