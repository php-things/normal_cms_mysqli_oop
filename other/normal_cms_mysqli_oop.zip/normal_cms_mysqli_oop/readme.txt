this is simple cms site for practices
oop with mysqli not well manage

=========== installation process==========
-unzip the folder
-copy that unzip file on your local sever on htdocs
-import database (127.0.0.1 database file name)
    if u get problem with importing database on your sever, 
    you can go through this way also
        --create "normal_cms" database 
	--and then u can import database

-and go to ur web browser type localhost:8080/normal_cms
-enjoy it 